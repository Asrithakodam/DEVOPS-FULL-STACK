# Food Delivery Backend — Docker Practical

A Node.js and Express REST API for restaurants, food items, and orders, packaged as a Docker image.

## Requirements

- Node.js 20+ and npm (for local testing)
- Docker Desktop or Docker Engine
- Postman (optional, for API testing)

## Project structure

```text
food-backend/
├── server.js
├── routes/
│   ├── restaurantRoutes.js
│   ├── foodRoutes.js
│   └── orderRoutes.js
├── package.json
├── package-lock.json
├── Dockerfile
├── .dockerignore
├── .gitignore
├── .env.example
└── README.md
```

## 1. Install and run locally

From this directory:

```bash
npm install
npm start
```

The API listens on `http://localhost:5000` by default. Set `PORT` to override the port.

## 2. API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Health check |
| GET | `/api/restaurants` | List restaurants |
| GET | `/api/restaurants/:id` | Get a restaurant by ID |
| GET | `/api/foods` | List food items |
| GET | `/api/foods/:id` | Get a food item by ID |
| POST | `/api/orders` | Create an order |
| GET | `/api/orders` | List orders |

### Create an order in Postman

- Method: `POST`
- URL: `http://localhost:5000/api/orders`
- Select **Body → raw → JSON** and send:

```json
{
  "customerName": "Swetha",
  "foodId": 101,
  "quantity": 2
}
```

A successful request returns `201 Created`.

## 3. Build the Docker image

Run these commands from the project root:

```bash
docker build -t food-backend:v1 .
docker images
```

The Dockerfile uses Node.js 20 Alpine, installs production dependencies, runs as a non-root user, and configures a health check.

## 4. Run the container

```bash
docker run -d --restart unless-stopped -p 5000:5000 -e PORT=5000 -e NODE_ENV=production --name food-api food-backend:v1
docker ps
```

If a container named `food-api` already exists, stop and remove it first:

```bash
docker stop food-api
docker rm food-api
```

Test these URLs in a browser or Postman:

- `http://localhost:5000/health`
- `http://localhost:5000/api/restaurants`
- `http://localhost:5000/api/foods`
- `http://localhost:5000/api/orders`

## 5. Container management

```bash
docker ps
docker ps -a
docker logs food-api
docker logs -f food-api
docker inspect food-api
docker stop food-api
docker start food-api
docker restart food-api
```

Check the health-check state:

```bash
docker inspect --format='{{json .State.Health}}' food-api
```

The health state may initially show `starting`. Wait for the first health check to run.

## 6. Docker network

Create the network:

```bash
docker network create food-network
```

To run the backend on the custom network, the container must be created with that network:

```bash
docker run -d --network food-network --restart unless-stopped -p 5000:5000 --name food-api food-backend:v1
```

Inspect the network:

```bash
docker network ls
docker network inspect food-network
```

If `food-api` already exists, stop and remove it before recreating it with the network option.

## 7. Image versioning

```bash
docker build -t food-backend:v2 .
docker tag food-backend:v2 food-backend:latest
docker images
```

Use explicit version tags such as `v1` and `v2` when deploying.

## Important limitations

- Restaurant and food data are sample arrays in source code.
- Orders are held in memory and are lost when the server restarts.
- A real production deployment should use persistent database storage, stronger request validation, authentication/authorization where required, and secure secrets management.
- The Docker health check checks whether `/health` responds; it does not verify every business operation or a database.

## Windows note

Commands split across lines using `\\` are for shells such as Bash. In Windows Command Prompt, enter the Docker command on one line, or use PowerShell's backtick for line continuation.

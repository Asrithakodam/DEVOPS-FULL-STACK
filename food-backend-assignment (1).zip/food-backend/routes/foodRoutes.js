const express = require("express");
const router = express.Router();

const foods = [
    { id: 101, name: "Chicken Biryani", restaurantId: 1, price: 220 },
    { id: 102, name: "Veg Biryani", restaurantId: 1, price: 180 }
];

// GET /api/foods - Get all food items
router.get("/", (req, res) => {
    res.json(foods);
});

// GET /api/foods/:id - Get one food item by ID
router.get("/:id", (req, res) => {
    const foodId = Number(req.params.id);
    const food = foods.find((item) => item.id === foodId);

    if (!food) {
        return res.status(404).json({ message: "Food not found" });
    }

    res.json(food);
});

module.exports = router;

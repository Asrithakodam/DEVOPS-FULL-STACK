const express = require("express");
const router = express.Router();

// Demonstration only: orders are stored in memory and reset when the server restarts.
const orders = [];
let nextOrderId = 1;

// POST /api/orders - Create an order
router.post("/", (req, res) => {
    const { customerName, foodId, quantity } = req.body || {};

    if (
        typeof customerName !== "string" ||
        customerName.trim().length === 0 ||
        !Number.isInteger(foodId) ||
        foodId <= 0 ||
        !Number.isInteger(quantity) ||
        quantity <= 0
    ) {
        return res.status(400).json({
            message: "Provide customerName, a positive integer foodId, and a positive integer quantity"
        });
    }

    const order = {
        id: nextOrderId++,
        customerName: customerName.trim(),
        foodId,
        quantity,
        status: "Placed"
    };

    orders.push(order);

    res.status(201).json({
        message: "Order placed successfully",
        order
    });
});

// GET /api/orders - Get all orders created since server startup
router.get("/", (req, res) => {
    res.json(orders);
});

module.exports = router;

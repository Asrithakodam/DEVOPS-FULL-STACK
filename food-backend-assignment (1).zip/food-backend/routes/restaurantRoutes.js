const express = require("express");
const router = express.Router();

const restaurants = [
    { id: 1, name: "Spice Kitchen", cuisine: "Indian" },
    { id: 2, name: "Pizza Palace", cuisine: "Italian" }
];

// GET /api/restaurants - Get all restaurants
router.get("/", (req, res) => {
    res.json(restaurants);
});

// GET /api/restaurants/:id - Get one restaurant by ID
router.get("/:id", (req, res) => {
    const restaurantId = Number(req.params.id);
    const restaurant = restaurants.find((item) => item.id === restaurantId);

    if (!restaurant) {
        return res.status(404).json({ message: "Restaurant not found" });
    }

    res.json(restaurant);
});

module.exports = router;
